Name: Quincy Manson

Hours to complete project: 7 hours

Feedback:Took a lot less time and was easier to figure out test cases for me. I didnt need to go to help room



External Sources (Attributions): Looked at Piazza

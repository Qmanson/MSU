Name: Quincy Manson

Feedback: Was challenging at first because I did not know python but after a little bit of working with
    Zybooks I was able to figure it out

Time Took: 5 hours

Resources: Zybooks, Piazza

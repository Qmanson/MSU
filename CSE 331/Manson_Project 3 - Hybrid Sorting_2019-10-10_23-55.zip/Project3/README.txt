Name: Quincy Manson

Hours to complete project: 12 hours

Feedback: Good longer then other projects to finish

External Sources (Attributions): HelpRoom and Zybooks
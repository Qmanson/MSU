Name: Quincy Manson

Hours to complete project: 10 hrs

Feedback: Very good, took enough critical thought but not to the point where i had no idea what was going on

External Sources (Attributions): (university of sanfrancisco heap visualization) https://www.cs.usfca.edu/~galles/visualization/Heap.html, and Piazza, and Class Notes
class Node:
    """
    Node definition should not be changed in any way
    """
    __slots__ = ['_key', '_value']

    def __init__(self, k, v):
        """
        Initializes node
        :param k: key to be stored in the node
        :param v: value to be stored in the node
        """
        self._key = k
        self._value = v

    def __lt__(self, other):
        """
        Less than comparator
        :param other: second node to be compared to
        :return: True if the node is less than other, False if otherwise
        """
        return self._key < other.get_key() or (self._key == other.get_key() and self._value < other.get_value())

    def __gt__(self, other):
        """
        Greater than comparator
        :param other: second node to be compared to
        :return: True if the node is greater than other, False if otherwise
        """
        return self._key > other.get_key() or (self._key == other.get_key() and self._value > other.get_value())

    def __eq__(self, other):
        """
        Equality comparator
        :param other: second node to be compared to
        :return: True if the nodes are equal, False if otherwise
        """
        return self._key == other.get_key() and self._value == other.get_value()

    def __str__(self):
        """
        Converts node to a string
        :return: string representation of node
        """
        return '({0},{1})'.format(self._key, self._value)

    __repr__ = __str__

    def get_key(self):
        """
        Key getter function
        :return: key value of the node
        """
        return self._key

    def set_key(self, new_key):
        """
        Key setter function
        :param new_key: the value the key is to be changed to
        """
        self._key = new_key

    def get_value(self):
        """
        Value getter function
        :return: value of the node
        """
        return self._value


class PriorityHeap:
    """
    Partially completed data structure. Do not modify completed portions in any way
    """
    __slots__ = '_data'

    def __init__(self):
        """
        Initializes the priority heap
        """
        self._data = []

    def __str__(self):
        """
        Converts the priority heap to a string
        :return: string representation of the heap
        """
        return ', '.join(str(item) for item in self._data)

    def __len__(self):
        """
        Length override function
        :return: Length of the data inside the heap
        """
        return len(self._data)

    __repr__ = __str__

#   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   Modify below this line

    def empty(self):
        """

        :return:
        """
        return self.__len__() == 0

    def top(self):
        """

        :return:
        """
        if self.empty():
            return None
        else:
            return self._data[0].get_value()

    def push(self, key, val):
        """

        :param key:
        :param val:
        :return:
        """
        insert_node = Node(key, val)
        self._data.append(insert_node)
        self.percolate_up(len(self._data)-1)

    def pop(self):
        """

        :return:
        """
        if not self.empty():
            if len(self._data) > 1:
                popped = self._data[0]
                self._data[0] = self._data[len(self._data)-1]
                self._data[len(self._data) - 1] = None
                self._data.pop(len(self._data) - 1)
                self.percolate_down(0)
                return popped
            else:
                popped = self._data[0]
                self._data.pop(0)
                return popped
        else:
            return None


    def min_child(self, index):
        """

        :param index:
        :return:
        """
        if index*2+2 < len(self._data) and self._data[index*2+1] is not None and self._data[index*2+2] is not None:
            if self._data[index*2+1].get_key() > self._data[index*2+2].get_key():
                return index*2+2
            else:
                return index*2+1
        elif index*2+1 < len(self._data) and self._data[index*2+1] is not None:
            return index*2+1
        elif index*2+2 < len(self._data) and self._data[index*2+2] is not None:
            return index*2+2
        else:
            return None

    def percolate_up(self, index):
        """

        :param index:
        :return:
        """
        while index >= 1 and self._data[(index-1)//2].get_key() >= self._data[index].get_key():
            if self._data[(index-1)//2].get_key() > self._data[index].get_key():
                temp = self._data[(index-1) // 2]
                self._data[(index-1) // 2] = self._data[index]
                self._data[index] = temp
            elif self._data[(index-1)//2].get_value() > self._data[index].get_value():
                temp = self._data[(index-1) // 2]
                self._data[(index-1) // 2] = self._data[index]
                self._data[index] = temp
            index = (index - 1) // 2
        return None

    def percolate_down(self, index):
        """

        :param index:
        :return:
        """
        min = self.min_child(index)
        while min is not None and self._data[min].get_key() < self._data[index].get_key():
            temp = self._data[min]
            self._data[min] = self._data[index]
            self._data[index] = temp
            index = min
            min = self.min_child(min)
        return None


    def change_priority(self, index, new_key):
        """

        :param index:
        :param new_key:
        :return:
        """
        if index < len(self._data):
            if self._data[index].get_key() > new_key:
                self._data[index].set_key(new_key)
                self.percolate_up(index)
            else:
                self._data[index].set_key(new_key)
                self.percolate_down(index)




def heap_sort(array):
    """
    :param array:
    :return:
    """
    size = len(array)
    heap = PriorityHeap()

    for i in range(size):
        elem = array.pop(0)
        heap.push(elem, elem)

    for i in range(size):
        array.append(heap.pop().get_value())

    return array

def merge_lists(array_list):
    """

    :param array_list:
    :return:
    """
    sum_size = 0
    heap = PriorityHeap()
    array = []
    for j in range(len(array_list)):
        size = len(array_list[j])
        for i in range(size):
            not_duplicate = True
            elem = array_list[j].pop(0)
            for k in range(len(heap)):
                a = heap._data[k].get_value()
                if a == elem:
                    not_duplicate = False
            if not_duplicate:
                heap.push(elem, elem)
                sum_size = sum_size + 1

    for i in range(sum_size):
        array.append(heap.pop().get_value())

    return array

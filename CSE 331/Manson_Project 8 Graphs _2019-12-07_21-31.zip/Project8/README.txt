Name: Quincy Manson

Hours to complete project: 6 hours

Feedback: Thanks for a good semester

External Sources (Attributions): Piazza, D2l slides, example code from d2l, zybooks chapter 27
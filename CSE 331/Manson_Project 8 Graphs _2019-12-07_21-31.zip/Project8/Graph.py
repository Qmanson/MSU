"""
Name:
PID:
"""

import random
from Project8.Heap import AdaptableHeapPriorityQueue

def generate_edges(size, connectedness):
    """
    DO NOT EDIT THIS METHOD
    Generates undirected edges between vertices to form a graph
    :return: A generator object that returns a tuple of the form (source ID, destination ID)
    used to construct an edge
    """
    assert connectedness <= 1
    random.seed(10)
    for i in range(size):
        for j in range(i + 1, size):
            if random.randrange(0, 100) <= connectedness * 100:
                w = random.randint(1, 20)
                yield [i, j, w]

class Graph:
    """
    Class representing a Graph
    """
    class Edge:
        """
        Class representing an Edge in the Graph
        """

        __slots__ = ['start', 'destination', 'weight']

        def __init__(self, start, destination, weight):
            """
            DO NOT EDIT THIS METHOD
            :param start: represents the starting vertex of the edge
            :param destination: represents the destination vertex of the edge
            :param weight: represents the weight of the edge
            """
            self.start = start
            self.destination = destination
            self.weight = weight

        def __eq__(self, other):
            """
            DO NOT EDIT THIS METHOD
            :param other: edge to compare
            :return: Bool, True if same, otherwise False
            """
            return self.start == other.start and \
                   self.destination.vertex_id == other.destination.vertex_id \
                   and self.weight == other.weight

        def __repr__(self):
            return f"Start: {self.start} Destination: {self.destination} Weight: {self.weight}"

        __str__ = __repr__

        def get_start(self):
            """
            Gets the edge's starting vertex_id
            :return: vertex_id, id of start
            """
            return self.start

        def get_destination(self):
            """
            Gets the edge's destination vertex_id
            :return: vertex_id, id of destination
            """
            return self.destination.vertex_id

        def get_weight(self):
            """
            Gets the edge's weight
            :return: int, weight of edge
            """
            return self.weight

    class Vertex:
        """
        Class representing an Edge in the Graph
        """

        __slots__ = ['vertex_id', 'edges', 'visited']

        def __init__(self, vertex_id):
            """
            DO NOT EDIT THIS METHOD
            :param vertex_id: represents the unique identifier of the vertex
            """
            self.vertex_id = vertex_id
            self.edges = {}
            self.visited = False

        def __eq__(self, other):
            """
            DO NOT EDIT THIS METHOD
            :param other: vertex to compare
            :return: Bool, True if the same, False otherwise
            """
            return self.vertex_id == other.vertex_id and \
                   self.edges == other.edges and self.visited == other.visited

        def __repr__(self):
            return f"Vertex: {self.vertex_id}"

        __str__ = __repr__

        def degree(self):
            """
            Finds the degree of the vertex
            :return: int,, degree of vertex
            """
            return len(self.edges)

        def visit(self):
            """
            Sets the vertex’s visit value to true
            """
            self.visited = True

        def insert_edge(self, destination, weight):
            """
            Adds an edge representation into the edge map between
            the vertex and the given destination vertex.
            :param destination: destination where edge ends
            :param weight: weight of the edge
            """
            edge = Graph.Edge(self.vertex_id, destination, weight)
            self.edges[destination.vertex_id] = edge

        def get_edge(self, destination):
            """
            Finds the specific edge that has the desired destination.
            :param destination: vertex of the destination
            :return: Edge, found egde or None
            """
            if self.edges.get(destination.vertex_id) is not None:
                return self.edges.get(destination.vertex_id)
            return None

        def get_edges(self):
            """
            Creates a list of the vertex’s edges.
            :return: list, list of edges on vertex
            """
            edge_list = []
            for edge in self.edges.values():
                edge_list.append(edge)
            return edge_list


    def __init__(self):
        """
        DO NOT EDIT THIS METHOD
        """
        self.adj_map = {}
        self.size = 0

    def __eq__(self, other):
        """
        DO NOT EDIT THIS METHOD
        Determines if 2 graphs are Identical
        :param other: Graph Object
        :return: Bool, True if Graph objects are equal
        """
        return self.adj_map == other.adj_map and self.size == other.size

    def add_to_graph(self, source, dest=None, weight=0):
        """
        Inserts a vertex into the graph and will create an edge if a
        destination and weight are provided. If the source or
        destination vertex does not exist in the graph then one will
        be created.
        :param source: vertex of source
        :param dest: vertex_id of destination
        :param weight: int weight of edge
        """
        if self.adj_map.get(source) is None:
            vertex = Graph.Vertex(source)
            self.adj_map[source] = vertex
            self.size += 1
        if dest is not None:
            if self.adj_map.get(dest) is None:
                vertex = Graph.Vertex(dest)
                self.adj_map[dest] = vertex
                self.size += 1
            self.adj_map[source].insert_edge(self.adj_map[dest], weight)
            self.adj_map[dest].insert_edge(self.adj_map[source], weight)

    def construct_graph_from_file(self, filename):
        """
        Can iterate through a provided file and update the graph
        with the vertices and edges that are in the file
        :param filename: file to be extracted
        """
        file = open(filename)
        for line in file:
            edge = line.split()
            start = edge[0]
            if start.isdigit():
                start = int(edge[0])
            if len(edge) != 1:
                end = edge[1]
                if end.isdigit():
                    end = int(edge[1])
                if len(edge) != 2:
                    weight = int(edge[2])
                else:
                    weight = 0
            else:
                end = None
                weight = 0
            self.add_to_graph(start, end, weight)

    def get_vertex(self, vertex_id):
        """
        Using the given vertex id retrieve the corresponding vertex object
        :param vertex_id: id of vertex to get
        :return: Vertex, vertex to get, if not there None
        """
        return self.adj_map.get(vertex_id)

    def get_vertices(self):
        """
        Creates a list of all the vertices in the graph
        :return: list, list of vertices in graph
        """
        vert_list = []
        for vertex in self.adj_map.values():
            vert_list.append(vertex)
        return vert_list

    def bfs(self, start, target, path=None):
        """
        Does a Breadth-First search to find a path between the start
        and the target visiting each node only once.
        :param start: vertex id of starting location
        :param target: vertex id of ending location
        :param path: optional list not used
        :return: list of path in bfs
        """
        queue = [[start]]
        self.get_vertex(start).visit()
        final = []
        while len(queue) != 0:
            next_queue = []
            for path_ in queue:
                for edge in self.get_vertex(path_[-1]).get_edges():
                    next_vert = self.get_vertex(edge.get_destination())
                    if not next_vert.visited:
                        temp_path = path_.copy()
                        temp_path.append(next_vert.vertex_id)
                        next_queue.append(temp_path)
                        next_vert.visit()
                        if next_vert == self.get_vertex(target):
                            return temp_path
                queue.remove(path_)
            queue.extend(next_queue)
        return []

    def dfs(self, start, target, path=None):
        """
        Does a Depth First Search  to find a path between the start
        and the target visiting each node only once.
        :param start: vertex id of starting location
        :param target: vertex id of ending location
        :param path: optional list used
        :return: list of path in dfs
        """
        if path is None or path == []:
            path = []
        self.get_vertex(start).visit()
        for edge in self.get_vertex(start).get_edges():
            v = edge.get_destination()
            if v == target:
                path.append(start)
                path.append(v)
                return path
            if not self.get_vertex(v).visited:
                path.append(start)
                val = self.dfs(v, target, path)
                if val is not None:
                    return val
                else:
                    path.pop()
        return None

def quickest_route(filename, start, destination):
    """
    Constructs graph with the given file and finds the path with
    the smallest total weight between the two given points.
    :param filename: file used to construct the graph
    :param start: vertex id of starting location
    :param destination: vertex id of ending location
    :return: List [total weight, IDs of vertices in the path], if no path then None
    """
    d = {}
    cloud = {}
    pq = AdaptableHeapPriorityQueue()
    vertex_path = []
    pqlocator = {}
    graph = Graph()
    graph.construct_graph_from_file(filename)

    if graph.get_vertex(destination) is None or graph.get_vertex(start) is None:
        return []

    for v in graph.get_vertices():
        if v.vertex_id == start:
            d[v.vertex_id] = 0
        else:
            d[v.vertex_id] = float('inf')
        pqlocator[v.vertex_id] = pq.add(d[v.vertex_id], v.vertex_id)


    while not pq.is_empty():
        key, u = pq.remove_min()
        cloud[u] = key
        if u == destination:
            temp = u
            while temp != start:
                vertex_path.append(str(temp))
                temp = pq.get_previous(pqlocator[temp])
            vertex_path.append(str(temp))
            break

        for e in graph.get_vertex(u).get_edges():  # outgoing edges (u,v)
            v = e.get_destination()
            if v not in cloud:
                # perform relaxation step on edge (u,v)
                wgt = e.get_weight()
                if d[u] + wgt < d[v]:  # better path to v?
                    d[v] = d[u] + wgt  # update the distance
                    pq.update(pqlocator[v], d[v], v, u)  # update the pq entry

    if destination in cloud:
        final_list = [cloud[destination]]
        vertex_path.reverse()
        final_list.extend(vertex_path)
        return final_list
    else:
        return []


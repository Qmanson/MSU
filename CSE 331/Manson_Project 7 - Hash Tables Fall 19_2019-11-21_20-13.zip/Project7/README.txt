Name: Quincy Manson

Hours to complete project: 6 Hours

Feedback: Easier then others 

External Sources (Attributions): (https://www.programiz.com/python-programming/methods/string/lower) python lower, Piazza, Help room 

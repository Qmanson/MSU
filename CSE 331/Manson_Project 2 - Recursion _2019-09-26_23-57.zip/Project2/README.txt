Name: Quincy Manson
Time: 4 hours
Feedback: Other functions were good and remove_fake_requests was pretty difficult
Sources Used:  https://www.cs.cmu.edu/~pattis/15-1XX/15-200/lectures/llrecursion/index.html (CMU online lecture on Recusion and linked lists)